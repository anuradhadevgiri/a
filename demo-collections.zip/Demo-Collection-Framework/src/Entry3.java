import java.util.HashSet;

class Person {
	private int age;
	private String name;

	public Person(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}

	@Override
	public String toString() {
		return name + "/"+ age;
	}

	@Override
	public int hashCode() {
//		System.out.println("\n\nhashCode of "+ this + ": "+ super.hashCode());
		System.out.println("\n\nhashCode of "+ this + ": "+ this.age);
//		return super.hashCode();
		return age;
	}
	
	@Override
	public boolean equals(Object obj) {
		
//		boolean flag = super.equals(obj);
		
//		boolean flag = this.name.equals(((Person)obj).name);
		
		boolean flag = (this.name.equals(((Person)obj).name)) && (this.age == ((Person)obj).age);
		
		
		System.out.println("Comaparing "+  this + " with "+ obj + ": "+ flag);
		return flag;
	}
	
	
	
	
	
	
	
}

public class Entry3 {

	public static void main(String[] args) {
		HashSet<Person> setOfPersons = new HashSet<Person>();
		
		setOfPersons.add(new Person(13, "vijay"));
		setOfPersons.add(new Person(13, "Vikas"));
		setOfPersons.add(new Person(13, "Vikas"));
		
		
		System.out.println(setOfPersons.size());
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
