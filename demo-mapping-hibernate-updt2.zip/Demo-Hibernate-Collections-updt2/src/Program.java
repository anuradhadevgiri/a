

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;

import com.cg.Bid;
import com.cg.Image;
import com.cg.Item;
import com.cg.util.HibernateUtilities;

public class Program {

	public static void main(String[] args) {
		System.out.println("Hello world");
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();

		Item itm = new Item();
		
		Set<String> simpleImages = new HashSet<String>();
		
		simpleImages .add("Flower");
		simpleImages .add("Animal");
		simpleImages .add("Plants");
		
		itm.setSimpleImages(simpleImages );
		itm.setCodee("56");
		
		
//		session.save(itm);

		Set<Image> componetImages = new HashSet<Image>();
		
		Image img = new Image();
		img.setName("NNA");
		
		
		Image img2 = new Image();
		
		componetImages.add(img);
		componetImages.add(img2);
		
		itm.setComponentImages(componetImages);

		
//		session.save(itm);
		
		
		
		
		
		
		
		
		
		
		
		
		Bid bid1 = new Bid();
		bid1.setPrice(2000);
		
		Bid bid2 = new Bid();
		bid2.setPrice(5000);
		
		Set<Bid> bids = new HashSet<Bid>();
		
		bids.add(bid1);
		bids.add(bid2);
		
		itm.setBids(bids);
		
/*		bid1.setItem(itm);
		bid2.setItem(itm);
*/		
		
	/*	session.save(bid1);
		session.save(bid2);
*/		

		session.save(itm);
		session.getTransaction().commit();
		
		
		
		
		
		
		
		
		session.close();
		
		
		
		HibernateUtilities.getSessionFactory().close();
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
