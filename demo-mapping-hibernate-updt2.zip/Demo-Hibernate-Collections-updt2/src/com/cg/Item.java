package com.cg;

import java.util.HashSet;
import java.util.Set;

public class Item {

	private Set<String> simpleImages = new HashSet<String>();
	
	private Set<Image> componentImages = new HashSet<Image>();
	
	private Set<Bid> bids = new HashSet<Bid>();
	
	public void setBids(Set<Bid> bids) {
		this.bids = bids;
	}
	
	public Set<Bid> getBids() {
		return bids;
	}
	
	public void addBid(Bid bid){
		bid.setItem(this);
		bids.add(bid);
	}
	
	
	
	
	public void setCodee(String code){
		
	}
	
	public String getCodee(){
		return "Dummy";
	}
	
	private int id;
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	

	public Set<Image> getComponentImages() {
		return componentImages;
	}

	public void setComponentImages(Set<Image> componentImages) {
		this.componentImages = componentImages;
	}

	public Set<String> getSimpleImages() {
		return simpleImages;
	}

	public void setSimpleImages(Set<String> simpleImages) {
		this.simpleImages = simpleImages;
	}
}
