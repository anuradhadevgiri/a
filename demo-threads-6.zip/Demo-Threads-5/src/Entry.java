import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;


public class Entry {
	public static void main(String[] args) {
		

		    Object a = new ArrayList();
		    System.out.print((a instanceof Collections)+",");
		    System.out.print((a instanceof Arrays)+",");
		    System.out.print(a instanceof List);

		    
		    
		    
		    
/*		ArrayList<Object> list = new ArrayList<String>();
		
		System.out.println(list instanceof List);
		
		
		Thread t1 = new MyThread();
		
//		t1.run();
		
		t1.start();

		
//		t1.interrupt();
*/		
		
	}
	
	
	
}

class MyThread extends Thread{
	
	@Override
	public void run() {

/*		try {
			while(true){
				System.out.println("MyThread...");
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
*/
		
		while(true){		
			try {
					System.out.println("MyThread...");
					Thread.sleep(1000);
				}
			 catch (InterruptedException e) {
				e.printStackTrace();
				
//				COMPLETE SOME TASK
				
				return;
			}
		}
		
	}
	
	
	
	
	
	
}









