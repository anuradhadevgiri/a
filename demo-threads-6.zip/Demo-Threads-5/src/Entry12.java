import com.cg.beans.other.Container;

public class Entry12 {
	public static void main(String[] args) {
		Container container = new Container();
		
		new ProducerThread(container).start();
		new ConsumerThread(container).start();
		
		
	}
	
	
	
}

class ProducerThread extends Thread {

	private Container container;

	public ProducerThread(Container container) {
		setName("PT");
		this.container = container;
	}

	@Override
	public void run() {
		try {
			while (true) {
				container.put();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class ConsumerThread extends Thread {

	private Container container;

	public ConsumerThread(Container container) {
		setName("CT");
		this.container = container;
	}

	@Override
	public void run() {
		try {
			while (true) {
				container.get();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
