package com.cg.util;

import com.cg.beans.Account;

public class WT implements Runnable {
	private Account account;

	public WT(Account account) {
		super();
		this.account = account;
	}

	@Override
	public void run() {
		while(true){
			try {
				account.withdraw(500);
				Account.showCount();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
