package com.cg.beans.other;

public class Container {
	
	private boolean isJobAvailable;
	
	synchronized
	public void put() throws InterruptedException{
		if(isJobAvailable){
//			WAIT TILL JOB IS NOT AVAILABLE
			this.wait();
		}
		
		Thread.sleep(900);
		System.out.println(isJobAvailable+ ", now JOB is now available....");
		
		isJobAvailable = true;
		this.notify();
	}
	
	synchronized
	public void get() throws InterruptedException{
		while(!isJobAvailable){
//			WAIT TILL JOB IS AVAILABLE
			this.wait();
		}
		
		Thread.sleep(900);
		System.out.println(isJobAvailable + " , nowJOB is now not available....");
		
//		isJobAvailable = false;
		this.notify();
	}
	
	
	
	
	
	
	
	
	
	
	
}
