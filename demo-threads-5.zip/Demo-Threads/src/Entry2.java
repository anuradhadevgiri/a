public class Entry2 {

	public static void main(String[] args) throws InterruptedException {
		String threadName = Thread.currentThread().getName();

//		Thread t1 = new Thread();
		
		Thread t1 = new MyNewThread();
		t1.setName("T1");
//		t1.run();
		
		t1.start();

		t1.interrupt();
		
		while (true) {
			System.out.println(Thread.currentThread().getName());
			Thread.sleep(800);
		}

	}

}

class MyNewThread extends Thread {
	
/*	@Override
	public synchronized void start() {
		run();
	}
*/	
	// @Override
	public void run() {
		String threadName = Thread.currentThread().getName();

		/*
		 * try { while(true){ System.out.println(threadName); Thread.sleep(800);
		 * } } catch (InterruptedException e) { e.printStackTrace(); }
		 */

		while (true) {
			try {

				System.out.println(threadName);
				Thread.sleep(800);

			} catch (InterruptedException e) {
				e.printStackTrace();
//				SKIP REST OF THE METHOD BODY
				return;
			}
		}

//		System.out.println("Last statement in thread...");

	}

}
