import com.cg.beans.other.Account;

public class Entry10 {
	public static void main(String[] args) {
		Account account = new Account();
		
		Thread t1 = new WT(account);
		t1.setName("Withdraw Thread");
		t1.start();		

		Thread t2 = new DT(account);
		t2.setName("Deposit Thread");
		t2.start();		

	}
}

class DT extends Thread {
	private Account ref;

	public DT(Account ref) {
		this.ref = ref;
	}

	@Override
	public void run() {

		ref.deposit();
		
	}
}

class WT extends Thread {
	private Account ref;

	public WT(Account ref) {
		this.ref = ref;
	}

	@Override
	public void run() {

		ref.withdraw();
		
	}
}
