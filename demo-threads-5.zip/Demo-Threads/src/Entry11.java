import com.cg.beans.Container;


public class Entry11 {
	
	private static Thread t1;
	
	public static void main(String[] args) {
		final Container container = new Container();
		

		t1 = new Thread("Producer Thread"){
				@Override
				public void run() {
					while(true){
						try {
							container.put();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
		};
		
		t1.start();
		
		new Thread(
					new Runnable(){
						public void run() {
							while(true){
								try {
									container.get();
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							}
						}
					}
				
				
				).start();
		
		
		
		
		
		Thread t2 = t1;
		
		
		
		
		
		
		
	}
}


