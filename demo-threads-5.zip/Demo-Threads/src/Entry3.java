import com.cg.beans.Account;
import com.cg.util.DT;
import com.cg.util.WT;


public class Entry3 {
	public static void main(String[] args) throws InterruptedException {
		
		Account account;
		
		account = new Account();
		
		Runnable target = new WT(account);
		
		Thread wt = new Thread(target,"WT");
		wt.start();
		

		Runnable target2 = new DT(account);
		
		Thread dt = new Thread(target2,"DT");
		dt.start();

		Account.showCount();
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
