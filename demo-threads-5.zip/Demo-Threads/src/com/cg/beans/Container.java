package com.cg.beans;

public class Container {
	private int size = 0;
	private boolean isProductAvailable;
	
//	synchronized
	public void put() throws InterruptedException{
		while(isProductAvailable){
			this.wait();
		}
		
		Thread.sleep(900);
		System.out.println("PUT");
		size++;
		
		isProductAvailable = true;
		this.notify();
	}
	
	synchronized
	public void get() throws InterruptedException{
		while(!isProductAvailable){
			this.wait();
		}
		
		Thread.sleep(900);
		System.out.println("GET");
		isProductAvailable = false;
		this.notify();
		size--;
		
	}
	
	
	
	
	
	
	
	
}
