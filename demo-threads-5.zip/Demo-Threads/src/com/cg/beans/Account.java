package com.cg.beans;

public class Account {
	private double balance;
	private int id;
	
	synchronized
	public void deposit(double amount) throws InterruptedException{
//		READ BALANCE
		double bal = this.balance;
		
//		MODIFY BALANCE
		Thread.sleep(900);
		bal += amount;
				
//		UPDATE BALANCE
		Thread.sleep(800);
		this.balance = bal;
	}
	
//	synchronized
	public void withdraw(double amount) throws InterruptedException{
//		READ BALANCE
		double bal = this.balance;
		
//		MODIFY BALANCE
		Thread.sleep(900);
		bal -= amount;
				
//		UPDATE BALANCE
		Thread.sleep(800);
		this.balance = bal;
	}
	

	synchronized
	public static void showCount() throws InterruptedException{
		
		Thread.sleep(1800);
		System.out.println(15);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
