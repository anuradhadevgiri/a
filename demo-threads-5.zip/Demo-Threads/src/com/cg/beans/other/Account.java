package com.cg.beans.other;

public class Account {

	synchronized
	public void withdraw(){
		System.out.println("READ");
		System.out.println("WITHDRAW");
		System.out.println("UPDATE");
	}
	
	synchronized
	public void deposit(){
		System.out.println("READ");
		System.out.println("DEPOSIT");
		System.out.println("UPDATE");
	}
	
	
}
