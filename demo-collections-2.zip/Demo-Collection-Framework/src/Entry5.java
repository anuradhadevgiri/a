import java.util.HashSet;

import com.cg.beans.Product;


public class Entry5 {
	private static HashSet<Product> products = new HashSet<Product>();
	
	public static void main(String[] args) {
		
		
		
		Product p1 = new Product("A/C", 40000);
		products.add(p1);
		
		Product p2 = new Product("Play-Station", 20000);
		products.add(p2);

		Product p5 = new Product("Laptop", 60000);
		products.add(p5);

		Product p3 = new Product("Mobile", 60000);
		products.add(p3);

		Product p4 = new Product("Mobile", 40000);
		products.add(p4);

		System.out.println(products.size());
		
		
		boolean flag = search(new Product("Mobile", 60000));
		
		System.out.println("Present: "+ flag);
		
		
		
	}
	
	public static boolean search(Product toBeSearched){
		return products.contains(toBeSearched);
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
