package bean;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
public class Album {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	String Name;
	@OneToMany
	List<Image> image;
	Date createDate;
	Date deleteDate;

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public List<Image> getImage() {
		return image;
	}

	public void setImage(List<Image> image) {
		this.image = image;
	}

	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	@Override
	public String toString() {
		return "Album [id=" + id + ", Name=" + Name + ", image=" + ", createDate=" + createDate + ", deleteDate="
				+ deleteDate + "images " + image + "]";
	}

}
