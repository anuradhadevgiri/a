package implclasses;

import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import bean.Actor;
import bean.Category;
import bean.Film;
import interfaces.ActorDAO;
import interfaces.ActorService;

public class ActorServiceImpl implements ActorService {

	private ActorDAO actorDAO;
	protected EntityManager em;

	public ActorServiceImpl(ActorDAO actorDAO) {
		this.actorDAO = actorDAO;
	}

	public ActorServiceImpl(EntityManager em) {
		this.em = em;
	}

	public Actor addActor(HashMap mapActor) {
		if (mapActor == null) {
			throw new NullPointerException();

		} else {

			try {
				Actor actor = new Actor();
				actor = actorDAO.save(actor);
				return actor;
			} catch (Exception e) {
				return null;
			}
		}
	}

	public Actor modifyActor(int id,Actor actor) {

		if (actor.equals(null)) {
			throw new NullPointerException();

		} else {
			try {
				  Actor savedActor=actorDAO.modifyActor(id,actor); 
					return savedActor;
				

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public String deleteActor(String name) {
		if (name.equals(null)) {
			throw new NullPointerException();
		} else {
			try {
				if (actorDAO.deleteActor(name))
					return "deleted";
				return "input not present";
			} catch (Exception e) {
				return "error";
			}

		}
	}

	public List<Actor> searchByName(String firstName, String lastName) {
		List<Actor> l = null;
		if (firstName.equals(null) || lastName.equals(null))
			throw new NullPointerException();
		try {
			l = actorDAO.searchByName(firstName, lastName);
			if (!l.isEmpty()) {
				return l;
			}
		} catch (Exception e) {
		}

		{
			return null;
		}
	}

}
