

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;

import com.cg.Image;
import com.cg.Item;
import com.cg.util.HibernateUtilities;

public class Program {

	public static void main(String[] args) {
		System.out.println("Hello world");
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();

		Item itm = new Item();
		
		Set<String> simpleImages = new HashSet<String>();
		
		simpleImages .add("Flower");
		simpleImages .add("Animal");
		simpleImages .add("Plants");
		
		itm.setSimpleImages(simpleImages );
		itm.setCodee("56");
		
		
		session.save(itm);

		Set<Image> componetImages = new HashSet<Image>();
		
		Image img = new Image();
		Image img2 = new Image();
		
		componetImages.add(img);
		componetImages.add(img2);
		
		itm.setComponentImages(componetImages);

		
		session.save(itm);
		
		
		
		
		
		
		
		
		
		
		
		
/*		Bid bid1 = new Bid();
		Set<Bid> bids = new HashSet<Bid>();
		bids.add(bid1);
		
		
		itm.setBids(bids);
*/
		
		
		session.getTransaction().commit();
		
		
		
		
		
		session.close();
		
		
		
		HibernateUtilities.getSessionFactory().close();
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
