import java.util.HashSet;


public class Entry2 {

	public static void main(String[] args) {
		HashSet<Integer> setOfValues = new HashSet<Integer>();
		
		
		setOfValues.add(10);
		setOfValues.add(10);
		
		setOfValues.add(10);
		
		setOfValues.add(10);
		
		
		System.out.println(setOfValues.size());
		
		
		
		
		
		
	}
	
	
	
	
	
	
}
