import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

import com.cg.beans.Product;


public class Entry6 {

	private static TreeSet<Product> products = new TreeSet<Product>();
	
	public static void main(String[] args) {
	
		Product p1 = new Product("A/C", 40000);
		products.add(p1);
		
		Product p2 = new Product("Play-Station", 20000);
		products.add(p2);


		Product p5 = new Product("Laptop", 60000);
		products.add(p5);

		Product p3 = new Product("Mobile", 60000);
		products.add(p3);

		Product p4 = new Product("Mobile", 40000);
		products.add(p4);

		
		System.out.println(products.size());
		
		
//		PRIOR TO JDK 5.0
/*		Iterator<Product> itr = products.iterator();
		
		while(itr.hasNext()){
			Product p = itr.next();
			System.out.println(p);
		}
*/		
		
//		STARTING WITH JDK 5.0
		
		for(Product p : products){
			System.out.print(p);
		}
		
		System.out.println();System.out.println();System.out.println();
		
//		CREATE A LOCAL CLASS
		
		class MyCustomComparator implements Comparator<Product>{
			@Override
			public int compare(Product o1, Product o2) {
				int diff = o1.getType().compareTo(o2.getType());
				
				if(diff == 0){
					diff = o1.getPrice() - o2.getPrice();
				}
				
				return diff;
			}
		}
		
		Comparator<Product> customComparator = new MyCustomComparator();
		TreeSet<Product> products2 = new TreeSet<Product>(customComparator);
		
		products2.addAll(products);
		
		p3 = new Product("Mobile", 80000);
		products2.add(p3);
		
		p3 = new Product("Mobile", 10000);
		products2.add(p3);
		
		
		
		for(Product p : products2){
			System.out.print(p);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
}
