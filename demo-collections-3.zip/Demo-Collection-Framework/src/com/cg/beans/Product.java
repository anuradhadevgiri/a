package com.cg.beans;

public class Product implements Comparable<Product> {
	private String type;
	private int price;

	
	public int getPrice() {
		return price;
	}
	
	public String getType() {
		return type;
	}
	
	
	@Override
	public int compareTo(Product o) {
		int diff = this.price - o.price;
		
		System.out.println(this + " comapred with "+ o);
		
		if(diff == 0){
			diff = this.type.compareTo(o.type);
		}
		
		
		return diff;
//		return 0;
	}
	
	
	public Product(String type, int price) {
		this.type = type;
		this.price = price;
	}

	@Override
	public int hashCode() {
//		int hc = super.hashCode();
		
		int hc = this.price;
		
		System.out.println(this + " has hashCode of "+ hc);
		
		return hc;
	}
	
	@Override
	public boolean equals(Object obj) {
//		REFERENCE VALUE EQUALITY
//		boolean flag = super.equals(obj);
	
//		STATE VALUE EQUALITY
		
		boolean flag = (this.type.equals(((Product)obj).type)) &&
				
				(this.price == ((Product)obj).price);
		
		System.out.println(this + " comapred with "+ obj + ": "+ flag);
		
		
		return flag;
	}
	
	
	
	
	
	
	
	
	
	
	@Override
	public String toString() {
//		return super.toString();
		
		String customMessage = "["+price + "/"+ type+"]";
		return customMessage;
	}
	
	
}
