package com.cg.beans;

public class Person implements Comparable<Person>{
	private String name;
	private int age;

	
	
	@Override
	public int compareTo(Person o) {
//		return 0;
		
		int diff;
		
		diff = this.age - o.age;
		
		System.out.println(this + " comapred with "+ o + ": "+ diff);
		
		return diff;
	}
	
	
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
//		return super.toString();
		
		String customMessage = "["+ name + "/" + age+"]";
		return customMessage;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getName() {
		return name;
	}
	
	
	
	
	
	
	
	
	
	
}
