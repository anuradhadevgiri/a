import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.TreeSet;

import com.cg.beans.Person;

public class Entry7 {
	public static void main(String[] args) {
		
		TreeSet<Person> tree = new TreeSet<Person>();
		
		Person p1 = new Person("Vikas",13);
		boolean flag = tree.add(p1);	

		System.out.println("Added? "+ p1 + ": "+ flag);
		
		Person p4 = new Person("ParDada",93);
		tree.add(p4);		
		
		System.out.println("Added? "+ p4 + ": "+ flag);

		Person p2 = new Person("Aman",18);
		tree.add(p2);		

		System.out.println("Added? "+ p2 + ": "+ flag);
		
		
		Person p3 = new Person("Dada",63);
		tree.add(p3);		

		System.out.println("Added? "+ p3 + ": "+ flag);

		System.out.println(tree.size());
		
		System.out.println("SHOWING TREE-SET USING COMAPARABLE");
		System.out.println(tree);
	
//		CREATING A LOCAL CLASS FOR IMPOSED ORDERING ON A PERSON
		
		class MyCustomComparator implements Comparator<Person>{
			@Override
			public int compare(Person o1, Person o2) {
//				return 0;
				
				int diff = o1.getName() .compareTo( o2.getName());
				
				System.out.println(o1 + " comapred with "+ o2 + ": "+ diff);
				return diff;
			}
		}
		
		Collections
		
		Comparator<Person> customComparator = new MyCustomComparator();
		TreeSet<Person> tree2 = new TreeSet<Person>(customComparator);
		
		tree2.addAll(tree);
		
		System.out.println("SHOWING TREE-SET USING COMPARATOR");
		
		System.out.println(tree2);
		
		
		
		
		
		
		
		
	}

	
	
	
	
	
	
	
	
	
	
}
