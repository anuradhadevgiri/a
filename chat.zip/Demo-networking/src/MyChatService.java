import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;


public class MyChatService {
	public static void main(String[] args) throws IOException {

//		REQUEST O.S. TO START THIS PROGRAM AS A SERVICE
		int port = 80;
		
		ServerSocket service = new ServerSocket(port);
		
		System.out.println("Service has started...");
		
//		ACCEPTING REQUEST FROM A CLIENT
		Socket clientSocket = service.accept();
		
		System.out.println("Connection established");
		
		
		InputStream in = clientSocket.getInputStream();
		
		InputStreamReader bridge = new InputStreamReader(in);
		BufferedReader br = new BufferedReader(bridge);
		
		while(true){

			String reqLINE = br.readLine();
			
			if(reqLINE == null){
				break;
			}
			
			System.out.println(reqLINE);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
