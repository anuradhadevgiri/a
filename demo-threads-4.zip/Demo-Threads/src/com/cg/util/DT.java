package com.cg.util;

import com.cg.beans.Account;

public class DT implements Runnable {
	private Account account;

	public DT(Account account) {
		super();
		this.account = account;
	}

	@Override
	public void run() {
		while(true){
			try {
				account.deposit(500);
				Account.showCount();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
