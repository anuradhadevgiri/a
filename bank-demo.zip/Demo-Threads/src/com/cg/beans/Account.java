package com.cg.beans;

public class Account {
	private int id;
	private double balance;

	public Account(int id, double balance) {
		this.id = id;
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public int getId() {
		return id;
	}

	public boolean deposit(double amount) throws InterruptedException{
		
		double balance = this.balance;
		
		Thread.sleep(800);
		
		balance += amount;
		
		Thread.sleep(600);
		
		this.balance = balance; 

		return true;
	}
	
	public boolean withdraw(double amount) throws InterruptedException{
		
		double balance = this.balance;
		
		Thread.sleep(800);
		
		balance -= amount;
		
		Thread.sleep(600);
		
		this.balance = balance; 

		return true;
	}
	
	
	
	
	
	
	
	
	
}
