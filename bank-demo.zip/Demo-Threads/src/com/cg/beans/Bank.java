package com.cg.beans;

public class Bank {
	private Account[] accounts;
	
	public Bank() {
	
		accounts = new Account[5];
		
		for(int id = 0; id < accounts.length; id++){
			accounts[id] = new Account(id, 5000);
		}
	
	}
	
	public boolean transferAmount(int toAcc,int fromAcc, double amount) throws InterruptedException{
		accounts[fromAcc].withdraw(amount);
		accounts[toAcc].deposit(amount);
		
		return true;
	}
	
	
	
	
	
	
	
	
	
}
