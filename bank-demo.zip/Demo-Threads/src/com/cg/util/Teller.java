package com.cg.util;

import com.cg.beans.Bank;

public class Teller implements Runnable{
	private Bank bankRef;

	@Override
	public void run() {
		try {
			doTransfer();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	public Teller(Bank bankRef) {
		super();
		this.bankRef = bankRef;
	}

	public boolean doTransfer() throws InterruptedException {
		int token = 0;
		
		while(token < 10){
			int toAcc = (int)(Math.random()* 5);
			int fromAcc = (int)(Math.random()* 5);
			
			bankRef.transferAmount(toAcc, fromAcc, 2000);
			
			
		}
		
		return true;
	}

}
