import com.cg.beans.Bank;
import com.cg.util.Teller;


public class Entry {
	public static void main(String[] args) {
		Bank bankRef = new Bank();
		
		Runnable target = new Teller(bankRef);
		
		Thread t1 = new Thread();
		
		t1.start();
		
		
		
	}
}
