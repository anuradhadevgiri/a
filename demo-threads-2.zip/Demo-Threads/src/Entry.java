
public class Entry {
	public static void main(String[] args) {
		
		
		Thread t1 = new MyThread();
		
//		t1.run();
		
		t1.start();

		
//		t1.interrupt();
		
		
	}
	
	
	
}

class MyThread extends Thread{
	
	@Override
	public void run() {

/*		try {
			while(true){
				System.out.println("MyThread...");
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
*/
		
		while(true){		
			try {
					System.out.println("MyThread...");
					Thread.sleep(1000);
				}
			 catch (InterruptedException e) {
				e.printStackTrace();
				
//				COMPLETE SOME TASK
				
				return;
			}
		}
		
	}
	
	
	
	
	
	
}









