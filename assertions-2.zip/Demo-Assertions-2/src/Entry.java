//	SINGLE TYPE IMPORT
import static com.cg.MyUtilities.m1;

import java.util.Set;
import java.util.TreeSet;

import com.cg.MyUtilities;
import com.cg.Person;


//	TYPE IMPORT ON DEMAND
//import static com.cg.MyUtilities.*;
//import static com.cg.MyUtilities.m2;

public class Entry {

	static public Set getPersons(){
		Set tree =  new TreeSet();
		
		Person p1 = new Person(45,"Baral");
		tree.add(p1);
		
		Person p2 = new Person(25,"Akash");
		tree.add(p2);
		
		Person p3 = new Person(26,"Sunil");
		tree.add(p3);
		
		Person p4 = new Person(75,"Devgan");
		tree.add(p4);
		
		return tree;
	}
	
	
	
	
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	
	public static void main(String[] args) {
		
		int distance = 90;
		
		System.out.println("distance is "+  distance);

		assert (distance >= 0);
		
		System.out.println("Some logic is being executed....");
		
		distance = -89;
		
		assert (distance >= 0);
		
		System.out.println(distance);
		System.out.println("end of main()...");
		
		com.cg.MyUtilities.m1();
		
		m1();
		
		MyUtilities.m2();
		
	}
	
	
	
}
