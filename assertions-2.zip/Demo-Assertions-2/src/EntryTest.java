import static org.junit.Assert.*;

import java.util.Set;
import java.util.TreeSet;

import org.junit.Assert;
import org.junit.Test;

import com.cg.Person;

public class EntryTest {

	@Test
	public void testSizeOfATreeSet(){
		Set expectedTree =  new TreeSet();
		
		Person p1 = new Person(45,"Baral");
		expectedTree.add(p1);
		
		Person p2 = new Person(25,"Akash");
		expectedTree.add(p2);

		Assert.assertEquals(2, expectedTree.size());
		
	}
	
	
	
	
	
	
	
	
	
	
	@Test
	public void testGetPersons() {
		
		Set expectedTree =  new TreeSet();
		
		Person p1 = new Person(45,"Baral");
		expectedTree.add(p1);
		
		Person p2 = new Person(25,"Akash");
		expectedTree.add(p2);
		
		Person p3 = new Person(26,"Sunil");
		expectedTree.add(p3);
		
		Person p4 = new Person(75,"Devgan");
		expectedTree.add(p4);

		System.out.println(expectedTree.size() + " in test case");
		
		Assert.assertEquals(4, expectedTree.size());
		
		Set actualTree = Entry.getPersons();
		Assert.assertEquals(expectedTree, actualTree);
		
		System.out.println(expectedTree);
		
		
//		fail("Not yet implemented");
	}

}
