package com.cg;

public class MyUtilities {

	public static void m1(){
		
	}

	public static void m2(){
		
	}

}
