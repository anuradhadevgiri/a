﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel; 

namespace WindowsFormsApplication1Assgnment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            int i;
            if (int.TryParse(txtempid.Text.ToString(), out i))
            {
                i = Convert.ToInt32(txtempid.Text);
            }
            else {
                MessageBox.Show("Please Enter Valid Employee Id");
                return;
            }
            if (txtcon.Text.Length == 10)
            {

            }
            else {
                MessageBox.Show("Plese enter valid contact number");
                return;
            }
            if(txtfname.Text==""){
                MessageBox.Show("Please enter Employee Name");
                return;
            }

            else if(txtlname.Text==""){
                MessageBox.Show("Please enter Last name");
                return;
            }

            else if (txtadd.Text == "") {
                MessageBox.Show("Please enter Adddress");
                return;
            }

            else if(dateTimePicker1.Text=="12/31/2016"){
                MessageBox.Show("Please enter date of birth");
                return;
            }

            else if (txtcon.Text == "")
            {
                MessageBox.Show("Please enter contact number");
                return;
            }

            else if (comdes.Text == "")
            {
                MessageBox.Show("Enter valid Designation");
                return;
            }

            else if (txtsal.Text == "")
            {
                MessageBox.Show("Please enter salary");
                return;
            }


            else if (codept.Text == "")
            {
                MessageBox.Show("Enter Department");
                return;
            }

            else if (txtsal.Text == "")
            {
                MessageBox.Show("Please enter salary");
                return;
            }
              Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;

            xlWorkBook = xlApp.Workbooks.Open("D:\\Assignment(70971_fs).xlsx");
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets[1];
            int lastUsedRow = xlWorkSheet.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell, misValue).Row;
            int a = lastUsedRow + 1;
            string p;
            if (a !=2)
            {
                for (int x=2; x<=a; x=x+1)
                {
                    p = Convert.ToString(xlWorkSheet.Cells[x, 1].value);

                    if (i == Convert.ToInt32(p))
                    {
                        MessageBox.Show(i + "This Emp code already Exists");
                        xlWorkBook.Save();
                        xlWorkBook.Close(true, misValue, misValue);
                        xlApp.Quit();
                        Marshal.ReleaseComObject(xlWorkSheet);
                        Marshal.ReleaseComObject(xlWorkBook);
                        Marshal.ReleaseComObject(xlApp);
                        return;
                    }
                }
            }

            xlWorkSheet.Cells[a, 1] = txtempid.Text;
            xlWorkSheet.Cells[a, 2] = txtfname.Text;
            xlWorkSheet.Cells[a, 3] = txtlname.Text;
            xlWorkSheet.Cells[a, 4] = txtadd.Text;
            xlWorkSheet.Cells[a, 5] = dateTimePicker1.Text;
            xlWorkSheet.Cells[a, 6] = txtcon.Text;
            xlWorkSheet.Cells[a, 7] = comdes.Text;
            xlWorkSheet.Cells[a, 8] = txtsal.Text;
            xlWorkSheet.Cells[a, 9] = codept.Text;
            xlWorkBook.Save();
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);
            MessageBox.Show("Data Added Successfully");
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, System.EventArgs e)
        {
            txtempid.Text = "";
            txtfname.Text = "";
            txtlname.Text = "";
            txtadd.Text = "";
            dateTimePicker1.Text = "";
            txtcon.Text = "";
            comdes.SelectedIndex = 0;
            txtsal.Text = "";
            codept.SelectedIndex = 0;
        }
        private void empid_TextChanged(object sender, EventArgs e)
        {
            txtempid.MaxLength = 5;
            int i;
            if (int.TryParse(txtempid.Text.ToString(), out i))
            {
                i = Convert.ToInt32(txtempid.Text);
            }
            else
            {
                if (txtempid.Text.Length >= 1)
                {
                    txtempid.Text = txtempid.Text.Remove(txtempid.Text.Length - 1);
                    MessageBox.Show("Employee id has to be numeric");
                    return;
                }
            }
        }
        private void fname_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtfname.Text, "^[a-zA-Z]+$"))
            {
            }
            else
            {
                if (txtfname.Text.Length >= 1)
                {
                    txtfname.Text = txtfname.Text.Remove(txtfname.Text.Length - 1);
                    MessageBox.Show("Enter only Alphabets");
                    return;
                }
            }
        }
        private void lname_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtlname.Text, "^[a-zA-Z]+$"))
            {
            }
            else
            {
                if (txtlname.Text.Length >= 1)
                {
                    txtlname.Text = txtlname.Text.Remove(txtlname.Text.Length - 1);
                    MessageBox.Show("Enter only Alphabets");
                    return;
                }
            }
        }

        private void con_TextChanged(object sender, EventArgs e)
        {
            txtcon.MaxLength = 10;
            double j;
            if (double.TryParse(txtcon.Text.ToString(), out j))
            {
                j = Convert.ToDouble(txtcon.Text);
            }
            else
            {
                if (txtcon.Text.Length >= 1)
                {
                    txtcon.Text = txtcon.Text.Remove(txtcon.Text.Length - 1);
                    MessageBox.Show("Contact has to be numeric");
                    return;
                }
            }
        }

        private void sal_TextChanged(object sender, EventArgs e)
        {
            int k;
            if (int.TryParse(txtsal.Text.ToString(), out k) && k > 0)
            {

                k = Convert.ToInt32(txtsal.Text);

            }
            else
            {
                if (txtsal.Text.Length >= 1)
                {
                    txtsal.Text = txtsal.Text.Remove(txtsal.Text.Length - 1);
                    MessageBox.Show("Please Enter Salary properly");
                    return;
                }
            }
        }

        private void but_close_Click(object sender, System.EventArgs e)
        {
            Application.Exit();

        }
    }
}



