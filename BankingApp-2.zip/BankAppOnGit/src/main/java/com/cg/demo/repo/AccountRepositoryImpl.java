package com.cg.demo.repo;

import com.cg.demo.beans.Account;

public class AccountRepositoryImpl implements AccountRepository {

	@Override
	public boolean save(Account a) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findByAccountnumber(int accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

}
