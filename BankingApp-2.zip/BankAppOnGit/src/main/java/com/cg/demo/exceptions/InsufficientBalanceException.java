package com.cg.demo.exceptions;

public class InsufficientBalanceException extends Exception {

}
