package com.cg.service;

import java.util.List;

import com.cg.model.Customer;
import com.cg.repository.CustomerRepository;

public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository customerRepository;

	public CustomerRepository getRepo(){
		System.out.println("INSIDE getRepo IMPL");
		return customerRepository;
	}
	
	
	public CustomerServiceImpl() {
		System.out.println("inside CustomerServiceImpl()");
		System.out.println("customerRepository ref: "+customerRepository);
	}
	
	public CustomerServiceImpl(CustomerRepository customerRepository) {
		System.out.println("customerRepository property is now available via constructor");
		this.customerRepository = customerRepository;
		System.out.println("customerRepository ref: "+customerRepository);
	}
	
	public void setCustomerRepository(CustomerRepository customerRepositoryRef) {
		System.out.println("1.customerRepository property is now available");
		this.customerRepository = customerRepositoryRef;
	}

	
	
	
	
	public void setCustomerRepository2(CustomerRepository customerRepositoryRef) {
		System.out.println("2.customerRepository property is now available");
		this.customerRepository = customerRepositoryRef;
	}

	public List<Customer> findAll() {
		return customerRepository.findAll();
	}

}
