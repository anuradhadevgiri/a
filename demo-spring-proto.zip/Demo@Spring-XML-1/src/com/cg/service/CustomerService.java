package com.cg.service;

import java.util.List;

import com.cg.model.Customer;
import com.cg.repository.CustomerRepository;

public interface CustomerService {

	List<Customer> findAll();

	public CustomerRepository getRepo();

}