import java.util.HashMap;
import java.util.Map;

import com.cg.beans.Employee;
import com.cg.beans.util.EmpKey;


public class Entry9 {
	public static void main(String[] args) {
		
		Map<EmpKey, Employee> mapOfEntries;
		
		mapOfEntries = new HashMap<EmpKey, Employee>();
		
		EmpKey key1 = new EmpKey(7645984, "FS");
		EmpKey key2 = new EmpKey(7645984, "TS");
		EmpKey key3 = new EmpKey(7645464, "FS");
		EmpKey key4 = new EmpKey(7645464, "FS");
		
		Employee e1 = new Employee("Arman", key1, 34);
		Employee e2 = new Employee("Aman", key2, 14);
		Employee e3 = new Employee("Rupesh", key3, 44);
		Employee e4 = new Employee("Rupesh", key3, 44);
		
		mapOfEntries.put(key1, e1);
		mapOfEntries.put(key2, e2);
		mapOfEntries.put(key3, e3);
		mapOfEntries.put(key4, e4);
		
		System.out.println(mapOfEntries);
		
		
		EmpKey toBeSearched = new EmpKey(7645464, "FS");
		
		Employee retrievedEmp = mapOfEntries.get(toBeSearched);
		
		System.out.println(retrievedEmp);
		
		
		
		
		
		
		
		
		
		
		
	}
}
