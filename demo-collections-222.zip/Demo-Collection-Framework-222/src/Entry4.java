import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;


public class Entry4 {
	public static void main(String[] args) {
		LinkedList<Integer> listOfValues;
		
		HashSet<Integer> setOfValues = new HashSet<Integer>();
		
		listOfValues = new LinkedList<Integer>();
		
		listOfValues.add(20);
		listOfValues.add(30);
		listOfValues.add(40);
		listOfValues.add(50);
		listOfValues.add(40);
		listOfValues.add(50);
		listOfValues.add(80);
		listOfValues.add(90);
		

		System.out.println(listOfValues.iterator().getClass());

		
		Iterator<Integer> itr = listOfValues.iterator();
		
		while(itr.hasNext()){
			int value = itr.next();
			
			System.out.print(value+ "\t");
			
		}
		System.out.println();
		
		setOfValues.addAll(listOfValues);
		
		itr = setOfValues.iterator();
		
		System.out.println(setOfValues.iterator().getClass());
		
		while(itr.hasNext()){
			int value = itr.next();
			
			System.out.print(value+ "\t");
			
		}
		
		System.out.println();
		
		
		
		
		
		
		
		
		
	}
}
