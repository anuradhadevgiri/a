package com.cg.beans.util;

public class EmpKey {
	private int id;
	private String unit;

	public EmpKey(int id, String unit) {
		super();
		this.id = id;
		this.unit = unit;
	}

	@Override
	public String toString() {
		return id + "_"+ unit;
	}
	
//	WE'VE NOT OVERRIDEN hashCode() and equals()

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		int hc ;
		
//		hc = super.hashCode();
		
		hc = unit.hashCode() * 31;
		
		System.out.println("hashCode of "+ this+ ": "+ hc);
		return hc;
		
	}
	
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		boolean flag ;
		
//		REFERENCE VALUE EQUALITY
//		flag= super.equals(obj);
		
//		OBJECT VALUE (STATE) EQUALITY
		flag = (this.unit.equals(((EmpKey)obj).unit)) && (this.id == ((EmpKey)obj).id);
		
		System.out.println(this + " compared "+ obj+ ": "+ flag);
		
		
		return flag;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
