package com.cg.beans;

import com.cg.beans.util.EmpKey;

public class Employee {
	private String name;
	private EmpKey id;
	private int age;

	public Employee(String name, EmpKey id, int age) {
		this.name = name;
		this.id = id;
		this.age = age;
	}

	@Override
	public String toString() {
		return name + "/"+ id + "/"+ age+"\n";
	}
	
	
}
