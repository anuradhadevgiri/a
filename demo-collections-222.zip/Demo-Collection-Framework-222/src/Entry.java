/*import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class Entry {
	public static void main(String[] args) {
		
		LinkedList<Integer> listOfValues;
		
		listOfValues = new LinkedList<Integer>();
		
		listOfValues.add(20);
		listOfValues.add(30);
		listOfValues.add(40);
		listOfValues.add(50);

		System.out.println(listOfValues.iterator().getClass());

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		FOR-EACH LOOP (FROM JDK 5.0)
		for(Integer i : listOfValues){
			System.out.print(i + "\t");
		}
		System.out.println();
		
		Iterator<Integer> itr = listOfValues.iterator();

		
	/*	while(itr.hasNext()){
			System.out.print(itr.next()+"\t");
		}
		
		System.out.println();

		
//		TYPE ERASURE
		boolean flag = (itr instanceof ListIterator<?>);

		
		if(flag){
			ListIterator<Integer> listItr = (ListIterator<Integer>)itr;
		
			System.out.println("listItr.previousIndex()"+listItr.previousIndex());;
			System.out.println("listItr.nextIndex()"+listItr.nextIndex());;
			
			while(listItr.hasPrevious()){
				System.out.print(listItr.previous()+"\t");
			}
			
		}
		
		System.out.println()
		;
		ListIterator<Integer> listItr2 =  listOfValues.listIterator(2);
		
		while(listItr2.hasPrevious()){
			System.out.print(listItr2.previous()+"\t");
		}
		
		
		
		
		
	}
}
*/