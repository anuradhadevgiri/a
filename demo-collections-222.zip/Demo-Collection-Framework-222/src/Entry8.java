
import java.util.TreeMap;

public class Entry8 {
	public static void main(String[] args) {
		TreeMap<Long, String> numbers = new TreeMap<Long, String>();
		
		
		numbers.put(9890098900L, "AirTel");
		numbers.put(9823098230L, "Hutch");
		numbers.put(9823098230L, "Vodafone");
		numbers.put(9990099900L, "AirCel");

		
		System.out.println(numbers.size());
//		WE DID LOOKUP
		String provider = numbers.get(new Long(9990099900L));
		System.out.println(provider);
		
		provider = numbers.get(new Long(9823098230L));
		System.out.println(provider);

	}
}
