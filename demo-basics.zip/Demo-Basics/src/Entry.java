import com.cg.beans.Contractor;
import com.cg.beans.Contractor.Details;
//import com.cg.beans.Contractor.Details;


public class Entry {
	public static void main(String[] args) {
		Contractor contractorRef;
		contractorRef = new Contractor();
		
//		boolean flag = (contractorRef instanceof Contractor.CBEmployee);
		
		Contractor.Details details = new Contractor.Details();
		
		Contractor.CBEmployee cbEmployeeRef;
		
		cbEmployeeRef = contractorRef.new CBEmployee();
		cbEmployeeRef.calculateWages();
		
//		System.out.println(new Contractor().new CBEmployee().hours);		
		
	}
}
