import com.cg.util.LinkedList;


public class Entry2 {
	public static void main(String[] args) {
		LinkedList list1 = new LinkedList();
		LinkedList list2 = new LinkedList();
		
		list1.add(10);
		list1.add(20);
		list1.add(30);
		
		
		list1.display();
		
		list2.add(35);
		
		list2.display();
		
	}
}
