import com.cg.utils.LinkedList;


public class Entry3 {
	public static void main(String[] args) {
		
		LinkedList list1 = new LinkedList();
		
		list1.add(12);
		list1.add(24);
		list1.add(36);
		list1.add(48);
		
		LinkedList list2 = new LinkedList();
		list2.add(60);
		
		list2.display();
		list1.display();
		
	}
}
