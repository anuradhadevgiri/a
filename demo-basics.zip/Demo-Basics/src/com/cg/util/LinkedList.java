package com.cg.util;

public class LinkedList {

	private Node head;
	private Node last;
	
	class Node{
		private int data;
		private Node next;
		
		public Node(int data) {
			this.data = data;
		}
		
		public int getData() {
			return data;
		}
	}// end of Node class definition
	
	
	public void add(int data){
		Node nu =  new Node(data);
		
		if(head == null){
			head = last = nu;
		}else{
			last.next  = nu;
			last = nu;
		}
	}

	public void display(){
		Node temp;
		
		temp = head;
		
		while(temp != null){
			System.out.print(temp.data+"\t");
			temp = temp.next;
		}
		
		System.out.println();
	}
	
	
	
	
	
	
	
}
