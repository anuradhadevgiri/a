package com.cg.beans;

//	OUTER CLASS (TOP-LEVEL CLASS)
public class Contractor {
	private String name;
	private int ratePerHour;
	
	private static int size;
	
	public void printSomeDetails(){
//		System.out.println(hours);
	}
	
	
//	THIS IS AN INNER CLASS
	public class CBEmployee extends Object{
		String name;
		private int hours;
		
		public CBEmployee() {
			// TODO Auto-generated constructor stub
			System.out.println(Contractor.size);
			System.out.println(this.name);		// employee's name
			System.out.println(Contractor.this.name);
			System.out.println(ratePerHour);
		}
		
		public void calculateWages(){
			double amt = ratePerHour * hours;
			Contractor.this.printSomeDetails();
		}
		
		
		
		
	}
	
	
//	THIS IS A PURE NESTED CLASS
	static public class Details {
		
		{
			System.out.println(size);
			System.out.println(new Contractor().new CBEmployee().hours);
			
			
		}
		
	}
	
	
	
}
