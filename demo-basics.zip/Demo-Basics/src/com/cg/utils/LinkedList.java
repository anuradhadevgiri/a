package com.cg.utils;

public class LinkedList {

	private Node head, last;
	
	
	class Node{
		private int data;
		private Node next;
		
		public Node(int data) {
			this.data = data;
		}
	}// end of Node class definition
	
	public boolean add(int data){
//		CREATE A NEW NODE
		LinkedList.Node nu;
		nu = this.new Node(data);
		
		if(head == null){
			head = last = nu;
		}else{
			last.next = nu;
			last = nu;
		}
		
		return true;
	}
	
	public void display(){
		Node temp = head;
		
		while(temp != null){
			System.out.print(temp.data + "\t");
			temp = temp.next;
		}
		
		System.out.println();
	}
	
	
	
	
	
	
	
	
}
