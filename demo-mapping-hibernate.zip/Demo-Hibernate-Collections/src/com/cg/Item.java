package com.cg;

import java.util.HashSet;
import java.util.Set;

public class Item {

	private Set<String> images = new HashSet<String>();
	private Set<Image> images2 = new HashSet<Image>();
	
	private Set<Bid> bids = new HashSet<Bid>();
	
	public void setBids(Set<Bid> bids) {
		this.bids = bids;
	}
	
	public Set<Bid> getBids() {
		return bids;
	}
	
	public void addBid(Bid bid){
		bid.setItem(this);
		bids.add(bid);
	}
	
	
	
	public Set<String> getImages() {
		return images;
	}
	
	
	public void setImages2(Set<Image> images2) {
		this.images2 = images2;
	}
	
	public Set<Image> getImages2() {
		return images2;
	}
	
	public void setCodee(String code){
		
	}
	
	public String getCodee(){
		return "Dummy";
	}
	
	private int id;
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
	
	public void setImages(Set<String> images) {
		this.images = images;
	}
}
