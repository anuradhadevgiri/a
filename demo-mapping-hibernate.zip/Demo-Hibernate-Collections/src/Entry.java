import javax.persistence.Persistence;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cg.beans.Address;
import com.cg.beans.Person;
import com.cg.util.HibernateUtilities;


public class Entry {
	public static void main(String[] args) {
		Address address = new Address();
		
		address.setCity("Hyderabad");
		address.setStreet("James street");
		address.setPinCode(500003);
		
		Person person = new Person();
		
		person.setAddress(address);
		person.setName("Manasa");
		person.setAge(16);
		
//		OBTAIN SESSION FACTORY
		SessionFactory sessionFactory = HibernateUtilities.getSessionFactory();
		
//		OPEN A SESSION
		Session session = sessionFactory.openSession();
		
//		START A TRANSACTION
		org.hibernate.Transaction tx =  session.beginTransaction();
		
//		DO SOME OPERATIONS

		session.save(person);
		
		
//		COMMIT TRANSACTIONS
		tx.commit();
		
		
//		CLOSE SESSION
		session.close();

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
