

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import org.hibernate.Session;

import com.cg.Bid;
import com.cg.Image;
import com.cg.Item;
import com.cg.util.HibernateUtilities;

public class Program {

	public static void main(String[] args) {
		System.out.println("Hello world");
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();

		Item itm = new Item();
		
		Set<String> images = new HashSet<String>();
		
		images.add("Flower");
		images.add("Animal");
		images.add("Plants");
		
		itm.setImages(images);
		itm.setCodee("56");
		
		
		session.save(itm);

		Set<Image> images2 = new HashSet<Image>();
		
		Image img = new Image();
		Image img2 = new Image();
		
		images2.add(img);
		images2.add(img2);
		
		itm.setImages2(images2);

		
		Bid bid1 = new Bid();
		Set<Bid> bids = new HashSet<Bid>();
		bids.add(bid1);
		
		
		itm.setBids(bids);

		
		
		session.getTransaction().commit();
		
		
		System.out.println(images2.iterator().next().getItem());
		
		
		
		session.close();
		
		
		
		HibernateUtilities.getSessionFactory().close();
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
